Network programming examples

Makefile
        "make clean; make" to compile everything

csapp.{c,h}
        CS:APP3e functions
echo.c
        Echo routine used by all of our echo server examples

echoclient.c
        Client for echo servers

echoserveri.c
        Iterative echo server

hostinfo.c
        Using getaddrinfo to get host IP address

tiny/
tiny.tar
        The Tiny Web server
