# comsil_hw
2020-1 컴퓨터공학 설계및 실험 1

<br><br>
## 프로젝트
![Eb16UaeUYAAvLGp](https://user-images.githubusercontent.com/50650579/135638730-aa2337ea-8f12-4fb7-a89e-8c1d34951c04.jpg)
![Eb16UabUwAAzoTe](https://user-images.githubusercontent.com/50650579/135638726-6d39fa23-f3a5-4ec3-b53b-512ea8ec531d.jpg)
![Eb16UafU0AAET9s](https://user-images.githubusercontent.com/50650579/135638733-94699b5e-9ad3-466d-be03-ae2f4636cc82.jpg)
![Eb16UabUMAEFiP5](https://user-images.githubusercontent.com/50650579/135638735-3a8b105b-3cf1-4316-89c0-b39bd2e20f02.jpg)
