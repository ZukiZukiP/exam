#include <stdio.h>
#include <stdlib.h>

void print(long long int* arr);
void start(long long int* arr);
void count(long long int page,long long int* arr);
