#include "header.h"

void print(long long int* arr){
	for(int i=0;i<10;i++){
		printf("%lld ",arr[i]);
}
	printf("\n");
}
