#include <stdio.h>
#include <stdlib.h>

void count(int n);
void print(int *arr);
